---
external help file: SitecoreFundamentals-help.xml
Module Name: SitecoreFundamentals
online version: 
schema: 2.0.0
---

# Add-WebFeatureHSTS

## SYNOPSIS

Installs the HSTS web feature.

## SYNTAX

```PowerShell
Add-WebFeatureHSTS [-HostName] <String> [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION

This cmdlet installs the HSTS web feature to a website.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------

```PowerShell
Add-WebFeatureHSTS -HostName 'sc.infosec'
```

This command configures HSTS for the 'sc.infosec' website.

## PARAMETERS

### -HostName

Hostname of website to configure.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm

Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf

Shows what would happen if the cmdlet runs. The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters

This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters <http://go.microsoft.com/fwlink/?LinkID=113216>.

## INPUTS

### None

## OUTPUTS

### None

## NOTES

## RELATED LINKS

[Remove-WebFeatureHSTS](Remove-WebFeatureHSTS.md)

[Test-WebFeatureHSTS](Test-WebFeatureHSTS.md)
