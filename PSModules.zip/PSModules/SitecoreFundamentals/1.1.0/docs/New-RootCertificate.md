---
external help file: SitecoreFundamentals-help.xml
Module Name: SitecoreFundamentals
online version:
schema: 2.0.0
---

# New-RootCertificate

## SYNOPSIS

Creates new self-signed X.509 certificate for signing certificates.

## SYNTAX

```PowerShell
New-RootCertificate [-Path] <String> [-Name <String>] [-StoreLocation <StoreLocation>] [-DnsName <String>]
 [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION

Creates a new self-signed certificate which can be installed in 'Trusted Root Authorities' and then used to sign other certificates.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------

```PowerShell
New-RootCertificate -Path '.build\certificates'
```

This command creates a X.509 certificate named 'root-authority.crt' in the '.build\certificates' folder

### -------------------------- EXAMPLE 2 --------------------------

```PowerShell
New-RootCertificate -Path '.build\certificates' -Name 'internal-site' -StoreLocation 'LocalMachine' -DnsName 'DevRoot'
```

This command creates a X.509 certificate with it's subject set to __CN=DevRoot__ in the `Cert:\LocalMachine\My` certificate store. The newly created certificate will be exported to the `.build\certificates\internal-site.crt` file.

## PARAMETERS

### -DnsName

Certificate common name

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: DO_NOT_TRUST_SitecoreFundamentalsRoot
Accept pipeline input: False
Accept wildcard characters: False
```

### -Name

Certificate filename without file extension

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: root-authority
Accept pipeline input: False
Accept wildcard characters: False
```

### -Path

Path to folder where the certificate file (.crt) will be created

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -StoreLocation

Specifies the store location to store self-signed certificate.

Possible values are:
    'CurrentUser' and 'LocalMachine'.

```yaml
Type: StoreLocation
Parameter Sets: (All)
Aliases:
Accepted values: CurrentUser, LocalMachine

Required: False
Position: Named
Default value: CurrentUser
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm

Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf

Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters

This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters <http://go.microsoft.com/fwlink/?LinkID=113216>.

## INPUTS

### None

## OUTPUTS

### PSObject containing __Certificate__ and __FileInfo__ properties

The __Certificate__ property contains the created root CA certificate.
The __FileInfo__ property contains file information about the exported certificate.

## NOTES

When creating certificates using the [IX509Enrollment](https://msdn.microsoft.com/en-us/library/windows/desktop/aa378051) interface the personal certificate store ('My') is used.

## RELATED LINKS

[New-SignedCertificate](New-SignedCertificate.md)

[Add-WebFeatureSSL](Add-WebFeatureSSL.md)