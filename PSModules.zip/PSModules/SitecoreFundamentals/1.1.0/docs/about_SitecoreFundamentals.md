# SitecoreFundamentals

## about_SitecoreFundamentals

## SHORT DESCRIPTION

Test and configure security settings in Sitecore instances.

## LONG DESCRIPTION

SitecoreFundamentals enables users to test and configure security settings in a Sitecore environment
using custom PowerShell functions.

The module provides cmdlets to test and configure support for:

* SSL
* HTTPSOnly
* HSTS

The `SitecoreFundamentals` PowerShell module is used by the new [Sitecore Installer](https://sitecore.myget.org/feed/sc-powershell/package/nuget/SitecoreInstallFramework) to perform security hardening functions during the installation process.