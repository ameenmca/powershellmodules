---
external help file: SitecoreFundamentals-help.xml
Module Name: SitecoreFundamentals
online version:
schema: 2.0.0
---

# Add-WebFeatureSSL

## SYNOPSIS

Installs the SSL web feature.

## SYNTAX

### Args (Default)

```PowerShell
Add-WebFeatureSSL [-HostName] <String> [-Port <Int32>] [-ClientCertLocation <String>]
 [-OutputDirectory <String>] [-RootDnsName <String>] [-RootCertName <String>] [-RootCertLocation <String>]
 [-WhatIf] [-Confirm] [<CommonParameters>]
```

### ArgsFilePath

```PowerShell
Add-WebFeatureSSL [-HostName] <String> [-Port <Int32>] [-ClientCertLocation <String>] -FilePath <String>
 [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION

This cmdlet installs the SSL web feature to the website specified by the HostName parameter.

The default _Args_ parameter set supports the development environment scenario where client and root CA certificates do not necessarily exist. Missing certificates will be created according to the parameter values passed to the cmdlet.

The cmdlet supports the scenario where an existing certificate is required to be applied to the website, use the _ArgsFilePath_ parameter set to perform this activity.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------

```PowerShell
Add-WebFeatureSSL `
       -HostName sc.infosec \`
       -Port 443 \`
       -OutputDirectory $env:TEMP \`
       -RootDnsName 'DO_NOT_TRUST_SitecoreFundamentalsRoot' \`
       -RootCertName 'root-authority' \`
       -RootCertLocation 'Cert:\LocalMachine\Root' \`
       -ClientCertLocation 'Cert:\LocalMachine\My'
```

This command configures SSL for the 'sc.infosec' website, creating the root CA and client certificates where required.

### -------------------------- EXAMPLE 2 --------------------------

```PowerShell
Add-WebFeatureSSL -HostName 'sc.infosec'
```

This command configures SSL for the 'sc.infosec' website using default settings for root CA and certificate naming, creating certificates where required.

### -------------------------- EXAMPLE 3 --------------------------

```PowerShell
Add-WebFeatureSSL -HostName 'sc.infosec' -FilePath '.\client.cert'
```

This command configures SSL for the 'sc.infosec' website using the client certificate specified by the FilePath parameter.

## PARAMETERS

### -ClientCertLocation

Certificate store to add signed website certificate in.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: Cert:\LocalMachine\My
Accept pipeline input: False
Accept wildcard characters: False
```

### -FilePath

Specifies the path to a certificate file to be imported. Acceptable formats include .sst, .p7b, and .cert files. If the file contains multiple certificates, then each certificate will be imported to the destination store.

```yaml
Type: String
Parameter Sets: ArgsFilePath
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -HostName

Hostname of website to configure.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -OutputDirectory

Directory to output certificate files to.

```yaml
Type: String
Parameter Sets: Args
Aliases:

Required: False
Position: Named
Default value: $env:TEMP
Accept pipeline input: False
Accept wildcard characters: False
```

### -Port

HTTPS Port number.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: 443
Accept pipeline input: False
Accept wildcard characters: False
```

### -RootCertLocation

Trusted root certificate store to add CA certificate in.

```yaml
Type: String
Parameter Sets: Args
Aliases:

Required: False
Position: Named
Default value: Cert:\LocalMachine\Root
Accept pipeline input: False
Accept wildcard characters: False
```

### -RootCertName

Root Certificate filename without file extension.

```yaml
Type: String
Parameter Sets: Args
Aliases:

Required: False
Position: Named
Default value: root-authority
Accept pipeline input: False
Accept wildcard characters: False
```

### -RootDnsName

Subject Name for certificate.

```yaml
Type: String
Parameter Sets: Args
Aliases:

Required: False
Position: Named
Default value: DO_NOT_TRUST_SitecoreFundamentalsRoot
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm

Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf

Shows what would happen if the cmdlet runs. The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters

This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters <http://go.microsoft.com/fwlink/?LinkID=113216>.

## INPUTS

### None

## OUTPUTS

### None

## NOTES

## RELATED LINKS

[Remove-WebFeatureSSL](Remove-WebFeatureSSL.md)

[Test-WebFeatureSSL](Test-WebFeatureSSL.md)