---
external help file: SitecoreFundamentals-help.xml
Module Name: SitecoreFundamentals
online version:
schema: 2.0.0
---

# Test-WebFeatureSSL

## SYNOPSIS

Tests whether the SSL web feature is enabled for a website.

## SYNTAX

```PowerShell
Test-WebFeatureSSL [-HostName] <String> [[-CertStoreLocation] <String>] [<CommonParameters>]
```

## DESCRIPTION

This cmdlet tests whether the SSL web feature is available for the website specified by the HostName parameter.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------

```PowerShell
Test-WebFeatureSSL -HostName 'sc.infosec' -CertStoreLocation 'Cert:\LocalMachine\My'
```

Reports on whether SSL has been enabled for 'sc.infosec' website using the Cert:\LocalMachine\My store.

## PARAMETERS

### -CertStoreLocation

Store to use to create certificates in.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: Cert:\LocalMachine\My
Accept pipeline input: False
Accept wildcard characters: False
```

### -HostName

Hostname of website to configure.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters

This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters <http://go.microsoft.com/fwlink/?LinkID=113216>.

## INPUTS

### None

## OUTPUTS

### True when feature found, False when feature not found

## NOTES

## RELATED LINKS

[Add-WebFeatureSSL](Add-WebFeatureSSL.md)

[Remove-WebFeatureSSL](Remove-WebFeatureSSL.md)