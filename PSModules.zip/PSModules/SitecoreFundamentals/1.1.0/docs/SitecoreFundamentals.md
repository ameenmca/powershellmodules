---
Module Name: SitecoreFundamentals
Module Guid: 9657d996-886a-4278-ac95-054801093485
Download Help Link: 
Help Version: 
Locale: en-US
---

# SitecoreFundamentals Module
## Description
The SitecoreFundamentals Module supports the testing and configuration of security settings in Sitecore instances.

## SitecoreFundamentals Cmdlets
### [Add-WebFeatureHSTS](Add-WebFeatureHSTS.md)
Installs the HSTS web feature.

### [Add-WebFeatureHTTPSOnly](Add-WebFeatureHTTPSOnly.md)
Installs the HTTPSOnly web feature.

### [Add-WebFeatureSSL](Add-WebFeatureSSL.md)
Installs the SSL web feature.

### [Get-WebFeature](Get-WebFeature.md)
Gets a list of available web features

### [New-RootCertificate](New-RootCertificate.md)
Creates new self-signed X.509 certificate for signing certificates.

### [New-SignedCertificate](New-SignedCertificate.md)
Creates new signed X.509 certificate for Server and Client Authentication.

### [Remove-WebFeatureHSTS](Remove-WebFeatureHSTS.md)
Removes the HSTS web feature.

### [Remove-WebFeatureHTTPSOnly](Remove-WebFeatureHTTPSOnly.md)
Removes the HTTPSOnly web feature.

### [Remove-WebFeatureSSL](Remove-WebFeatureSSL.md)
Removes the SSL web feature.

### [Test-WebFeatureHSTS](Test-WebFeatureHSTS.md)
Tests whether the HSTS web feature is enabled.

### [Test-WebFeatureHTTPSOnly](Test-WebFeatureHTTPSOnly.md)
Tests whether the HTTPSOnly web feature is enabled.

### [Test-WebFeatureSSL](Test-WebFeatureSSL.md)
Tests whether the SSL web feature is enabled for a website.

