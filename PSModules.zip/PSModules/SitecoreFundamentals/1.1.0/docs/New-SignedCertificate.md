---
external help file: SitecoreFundamentals-help.xml
Module Name: SitecoreFundamentals
online version:
schema: 2.0.0
---

# New-SignedCertificate

## SYNOPSIS

Creates new signed X.509 certificate for Server and Client Authentication.

## SYNTAX

```PowerShell
New-SignedCertificate [-Path] <String> [-Signer] <X509Certificate2> [-Name <String>]
 [-CertStoreLocation <String>] [-DnsName <String>] [-FriendlyName <String>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION

Creates a new signed certificate which can be installed in a certificate store and used for Client and Server Authentication purposes.

## EXAMPLES

### Example 1

```PowerShell
New-SignedCertificate -Signer (Get-Item -Path  'Cert:\CurrentUser\My\07B462C694139C0D1D2B9AE567AF8E7B755C1F46') -Path 'c:\temp' -CertStoreLocation 'Cert:\LocalMachine\My' -DnsName 'sc.infosec'
```

The command locates the signing certificate and passes this in the _Signer_ parameter to the `New-SelfSignedCertificate` cmdlet. The command will create a signed certificate in the _Cert:\LocalMachine\My_ certificate store with a _Subject_ set to __CN=sc.infosec__ and _FriendlyName_ defaulted to __sc.infosec__.

## PARAMETERS

### -CertStoreLocation

Certificate store location to create the X.509 certificate in.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: Cert:\LocalMachine\My
Accept pipeline input: False
Accept wildcard characters: False
```

### -DnsName

Specifies one or more DNS names to put into the subject alternative name extension of the certificate when a certificate to be copied is not specified via the CloneCert parameter. The first DNS name is also saved as the Subject Name. If no signing certificate is specified, the first DNS name is also saved as the Issuer Name.

_Currently only a single DNS name is supported_.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: Name parameter value, this defaults to gateway
Accept pipeline input: False
Accept wildcard characters: False
```

### -FriendlyName

Specifies a friendly name for the new certificate.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: DnsName parameter value, this defaults to gateway
Accept pipeline input: False
Accept wildcard characters: False
```

### -Name

Certificate filename without file extension

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: gateway
Accept pipeline input: False
Accept wildcard characters: False
```

### -Path

Path to folder where the certificate file (.crt) will be created

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Signer

Specifies the __Certificate__ object with which this cmdlet signs the new certificate. This value must be in the Personal certificate store of the user or device. This cmdlet must have read access to the private key of the certificate.

```yaml
Type: X509Certificate2
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm

Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf

Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters

This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters <http://go.microsoft.com/fwlink/?LinkID=113216>.

## INPUTS

### Microsoft.CertificateServices.Commands.Certificate

The Certificate object can either be provided as a Path object to a certificate or an X509Certificate2 object.

## OUTPUTS

### PSObject containing __Certificate__ and __FileInfo__ properties

The __Certificate__ property contains the created signed certificate.
The __FileInfo__ property contains file information about the exported certificate.

## NOTES

## RELATED LINKS

[New-RootCertificate](New-RootCertificate.md)

[Add-WebFeatureSSL](Add-WebFeatureSSL.md)