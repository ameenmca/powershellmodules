---
external help file: SitecoreFundamentals-help.xml
Module Name: SitecoreFundamentals
online version: 
schema: 2.0.0
---

# Get-WebFeature

## SYNOPSIS

Gets a list of available web features

## SYNTAX

```PowerShell
Get-WebFeature [<CommonParameters>]
```

## DESCRIPTION

This cmdlet list available web features.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------

```PowerShell
Get-WebFeature
```

Retrieves a list of available web features.

## PARAMETERS

### CommonParameters

This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters <http://go.microsoft.com/fwlink/?LinkID=113216>.

## INPUTS

## OUTPUTS

## NOTES

## RELATED LINKS
