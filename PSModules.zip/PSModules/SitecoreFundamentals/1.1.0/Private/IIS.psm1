#Requires -Modules WebAdministration
Set-StrictMode -Version Latest

Import-Module -Name (Join-Path -Path $PSScriptRoot -ChildPath 'Assertions.psm1')
Import-Module -Name (Join-Path -Path $PSScriptRoot -ChildPath 'CommonResourceHelper.psm1')

AssertWebAdministration -ScriptName $MyInvocation.MyCommand.Name

$httpCookiesFilter = "/system.web/httpCookies"

function GetSite {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name
	)

	$site = Get-Website -Name $Name

	if ($null -eq $site) {
		NewInvalidArgumentException -Message "$Name website not found" -ArgumentName 'Name'
	}
	else {
		return $site
	}
}

function GetSitePSPath {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
	)

	return "MACHINE/WEBROOT/APPHOST/{0}" -f (GetSite -Name $HostName).name
}

function GetWebConfigPath {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
	)

	return "{0}\web.config" -f (GetSite -Name $HostName).physicalPath
}

function SetCookieSecurity {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
		,
		[Parameter(Mandatory=$true)]
		[ValidateSet('On', 'Off')]
		[string] $Action
	)

	Write-Verbose "SetCookieSecurity: set $Action for $HostName"

	$psPath = GetSitePSPath -HostName $HostName

	if ($Action -eq 'On')
	{
		$httpOnlyFilter = "$httpCookiesFilter/@httpOnlyCookies"
		$requireSSLFilter = "$httpCookiesFilter/@requireSSL"

		Write-Verbose "SetCookieSecurity: set $httpOnlyFilter True"
		Set-WebConfiguration -Filter $httpOnlyFilter -PSPath $psPath -Value $true

		Write-Verbose "SetCookieSecurity: set $requireSSLFilter True"
		Set-WebConfiguration -Filter $requireSSLFilter -PSPath $psPath -Value $true

		Write-Verbose "SetCookieSecurity: lock configuration item $httpCookiesFilter"
		Add-WebConfigurationLock -Filter $httpCookiesFilter -PSPath $psPath -Type "general"
	}
	else
	{
		Write-Verbose "SetCookieSecurity: removing $httpCookiesFilter from web.config"
		Clear-WebConfiguration -Filter $httpCookiesFilter -PSPath $psPath
	}
}

function GetCookieSecurity {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
	)

	Write-Verbose "GetCookieSecurity: Evaluate web $httpCookiesFilter configuration for $HostName"

	$psPath = GetSitePSPath -HostName $HostName

	$webConfigSettings = Get-WebConfiguration -Filter $httpCookiesFilter -PSPath $psPath

	if ($null -eq $webConfigSettings)
	{
		Write-Verbose "GetCookieSecurity: Failed to get web configuration for site $HostName"
		return $null
	}

	return $webConfigSettings
}

function GetSiteManagedModule {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
		,
		[Parameter(Mandatory=$false)]
		[string] $Name
	)

	$psPath = GetSitePSPath -HostName $HostName

	if ($Name)
	{
		return Get-WebManagedModule -Name $Name -PSPath $psPath
	}
	else
	{
		return Get-WebManagedModule -PSPath $psPath
	}
}

function RemoveSiteManagedModule {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
		,
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name
	)

	$psPath = GetSitePSPath -HostName $HostName

	$moduleNames = Get-WebConfigurationProperty -PSPath $psPath -Name Collection -Filter /system.webServer/modules | Select-Object -ExpandProperty Name
	if ($moduleNames) {
		$index = $moduleNames.IndexOf($Name)
		if ($index -gt -1) {
			Write-Verbose "RemoveSiteManagedModule: removing $Name from site $HostName"
			Remove-WebConfigurationProperty -PSPath $psPath -Name Collection -Filter /system.webServer/modules -AtIndex $index
			return
		}
	}

	Write-Verbose "RemoveSiteManagedModule: $Name module does not exist in site $HostName, skipping"
}

function NewSiteManagedModule {

	param
	(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
		,
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name
		,
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Type
		,
		[Parameter(Mandatory=$false)]
		[string] $Predecessor = "SitecorePerRequestScopeModule"
	)

	Write-Verbose "NewSiteManagedModule: adding $Name ($Type) to site $HostName"

	$module = GetSiteManagedModule -HostName $HostName -Name $Name

	if ($null -eq $module)
	{
		Write-Verbose "NewSiteManagedModule: adding $Name ($Type) to site $HostName"

		WebManagedModuleInsertAfter -HostName $HostName -Name $Name -Type $Type -Predecessor $Predecessor
	}
	else
	{
		$installedType = $module.Type

		if ($installedType -ne $Type)
		{
			Write-Verbose "NewSiteManagedModule: replace $Name ($installedType) in site $HostName with $Type"

			RemoveSiteManagedModule -HostName $HostName -Name $Name

			WebManagedModuleInsertAfter -HostName $HostName -Name $Name -Type $Type -Predecessor $Predecessor
		}
		else
		{
			Write-Verbose "NewSiteManagedModule: $Name ($installedType) already in site $HostName, skipping"
		}
	}
}

function WebManagedModuleInsertAfter {

	param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
		,
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Name
		,
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $Type
		,
		[Parameter(Mandatory=$false)]
		[string] $Predecessor = "SitecorePerRequestScopeModule"
	)

	$site = GetSite -Name $HostName
	$webConfigPath = "{0}\web.config" -f $site.physicalPath
	$xml = [xml](Get-Content $webConfigPath)

	foreach ($item in  $xml.configuration."system.webServer".modules.add)
	{
		if ($item.name -eq $Predecessor)
		{
			$newNode = $xml.CreateElement("add")
			$newNode.SetAttribute("name", $Name)
			$newNode.SetAttribute("type", $Type)

			$xml.configuration."system.webServer".modules.InsertAfter($newNode, $item)
		}
	}
	$xml.Save($webConfigPath)
}

function CopySitecoreFundamentalsToWebsite {

	param(
		[Parameter(Mandatory=$true)]
		[ValidateScript({ Test-Path $_ -Type Container })]
		[string] $ContentPath
		,
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $HostName
	)

	$websiteDirectory = (GetSite -Name $HostName).PhysicalPath
	$contentFiles = 'bin\Sitecore.Fundamentals.dll' , 'App_Config\Include\Fundamentals\Sitecore.Fundamentals.config'

	$contentFiles | ForEach-Object {
		$srcFile = Join-Path -Path $ContentPath -ChildPath $_
		$destination = Join-Path -Path $websiteDirectory -ChildPath (Split-Path -Path $_)
		Copy-Item -Path $srcFile -Destination (New-Item $destination -Type container -Force) -Force
	}
}

Export-ModuleMember -Function @(
								'CopySitecoreFundamentalsToWebsite',
								'GetCookieSecurity',
								'GetSite',
								'GetSiteManagedModule',
								'GetSitePSPath',
								'GetWebConfigPath',
								'NewSiteManagedModule',
								'RemoveSiteManagedModule',
								'SetCookieSecurity'
							  )
# SIG # Begin signature block
# MIIXwQYJKoZIhvcNAQcCoIIXsjCCF64CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUUGug5M2p3F+vu1fp55abTA17
# BNygghL8MIID7jCCA1egAwIBAgIQfpPr+3zGTlnqS5p31Ab8OzANBgkqhkiG9w0B
# AQUFADCBizELMAkGA1UEBhMCWkExFTATBgNVBAgTDFdlc3Rlcm4gQ2FwZTEUMBIG
# A1UEBxMLRHVyYmFudmlsbGUxDzANBgNVBAoTBlRoYXd0ZTEdMBsGA1UECxMUVGhh
# d3RlIENlcnRpZmljYXRpb24xHzAdBgNVBAMTFlRoYXd0ZSBUaW1lc3RhbXBpbmcg
# Q0EwHhcNMTIxMjIxMDAwMDAwWhcNMjAxMjMwMjM1OTU5WjBeMQswCQYDVQQGEwJV
# UzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFu
# dGVjIFRpbWUgU3RhbXBpbmcgU2VydmljZXMgQ0EgLSBHMjCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBALGss0lUS5ccEgrYJXmRIlcqb9y4JsRDc2vCvy5Q
# WvsUwnaOQwElQ7Sh4kX06Ld7w3TMIte0lAAC903tv7S3RCRrzV9FO9FEzkMScxeC
# i2m0K8uZHqxyGyZNcR+xMd37UWECU6aq9UksBXhFpS+JzueZ5/6M4lc/PcaS3Er4
# ezPkeQr78HWIQZz/xQNRmarXbJ+TaYdlKYOFwmAUxMjJOxTawIHwHw103pIiq8r3
# +3R8J+b3Sht/p8OeLa6K6qbmqicWfWH3mHERvOJQoUvlXfrlDqcsn6plINPYlujI
# fKVOSET/GeJEB5IL12iEgF1qeGRFzWBGflTBE3zFefHJwXECAwEAAaOB+jCB9zAd
# BgNVHQ4EFgQUX5r1blzMzHSa1N197z/b7EyALt0wMgYIKwYBBQUHAQEEJjAkMCIG
# CCsGAQUFBzABhhZodHRwOi8vb2NzcC50aGF3dGUuY29tMBIGA1UdEwEB/wQIMAYB
# Af8CAQAwPwYDVR0fBDgwNjA0oDKgMIYuaHR0cDovL2NybC50aGF3dGUuY29tL1Ro
# YXd0ZVRpbWVzdGFtcGluZ0NBLmNybDATBgNVHSUEDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCAQYwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0y
# MDQ4LTEwDQYJKoZIhvcNAQEFBQADgYEAAwmbj3nvf1kwqu9otfrjCR27T4IGXTdf
# plKfFo3qHJIJRG71betYfDDo+WmNI3MLEm9Hqa45EfgqsZuwGsOO61mWAK3ODE2y
# 0DGmCFwqevzieh1XTKhlGOl5QGIllm7HxzdqgyEIjkHq3dlXPx13SYcqFgZepjhq
# IhKjURmDfrYwggSjMIIDi6ADAgECAhAOz/Q4yP6/NW4E2GqYGxpQMA0GCSqGSIb3
# DQEBBQUAMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMB4XDTEyMTAxODAwMDAwMFoXDTIwMTIyOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTQwMgYDVQQDEytT
# eW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIFNpZ25lciAtIEc0MIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAomMLOUS4uyOnREm7Dv+h8GEKU5Ow
# mNutLA9KxW7/hjxTVQ8VzgQ/K/2plpbZvmF5C1vJTIZ25eBDSyKV7sIrQ8Gf2Gi0
# jkBP7oU4uRHFI/JkWPAVMm9OV6GuiKQC1yoezUvh3WPVF4kyW7BemVqonShQDhfu
# ltthO0VRHc8SVguSR/yrrvZmPUescHLnkudfzRC5xINklBm9JYDh6NIipdC6Anqh
# d5NbZcPuF3S8QYYq3AhMjJKMkS2ed0QfaNaodHfbDlsyi1aLM73ZY8hJnTrFxeoz
# C9Lxoxv0i77Zs1eLO94Ep3oisiSuLsdwxb5OgyYI+wu9qU+ZCOEQKHKqzQIDAQAB
# o4IBVzCCAVMwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAO
# BgNVHQ8BAf8EBAMCB4AwcwYIKwYBBQUHAQEEZzBlMCoGCCsGAQUFBzABhh5odHRw
# Oi8vdHMtb2NzcC53cy5zeW1hbnRlYy5jb20wNwYIKwYBBQUHMAKGK2h0dHA6Ly90
# cy1haWEud3Muc3ltYW50ZWMuY29tL3Rzcy1jYS1nMi5jZXIwPAYDVR0fBDUwMzAx
# oC+gLYYraHR0cDovL3RzLWNybC53cy5zeW1hbnRlYy5jb20vdHNzLWNhLWcyLmNy
# bDAoBgNVHREEITAfpB0wGzEZMBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMjAdBgNV
# HQ4EFgQURsZpow5KFB7VTNpSYxc/Xja8DeYwHwYDVR0jBBgwFoAUX5r1blzMzHSa
# 1N197z/b7EyALt0wDQYJKoZIhvcNAQEFBQADggEBAHg7tJEqAEzwj2IwN3ijhCcH
# bxiy3iXcoNSUA6qGTiWfmkADHN3O43nLIWgG2rYytG2/9CwmYzPkSWRtDebDZw73
# BaQ1bHyJFsbpst+y6d0gxnEPzZV03LZc3r03H0N45ni1zSgEIKOq8UvEiCmRDoDR
# EfzdXHZuT14ORUZBbg2w6jiasTraCXEQ/Bx5tIB7rGn0/Zy2DBYr8X9bCT2bW+IW
# yhOBbQAuOA2oKY8s4bL0WqkBrxWcLC9JG9siu8P+eJRRw4axgohd8D20UaF5Mysu
# e7ncIAkTcetqGVvP6KUwVyyJST+5z3/Jvz4iaGNTmr1pdKzFHTx/kuDDvBzYBHUw
# ggUrMIIEE6ADAgECAhAHplztCw0v0TJNgwJhke9VMA0GCSqGSIb3DQEBCwUAMHIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJ
# RCBDb2RlIFNpZ25pbmcgQ0EwHhcNMTcwODIzMDAwMDAwWhcNMjAwOTMwMTIwMDAw
# WjBoMQswCQYDVQQGEwJVUzELMAkGA1UECBMCY2ExEjAQBgNVBAcTCVNhdXNhbGl0
# bzEbMBkGA1UEChMSU2l0ZWNvcmUgVVNBLCBJbmMuMRswGQYDVQQDExJTaXRlY29y
# ZSBVU0EsIEluYy4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC7PZ/g
# huhrQ/p/0Cg7BRrYjw7ZMx8HNBamEm0El+sedPWYeAAFrjDSpECxYjvK8/NOS9dk
# tC35XL2TREMOJk746mZqia+g+NQDPEaDjNPG/iT0gWsOeCa9dUcIUtnBQ0hBKsuR
# bau3n7w1uIgr3zf29vc9NhCoz1m2uBNIuLBlkKguXwgPt4rzj66+18JV3xyLQJoS
# 3ZAA8k6FnZltNB+4HB0LKpPmF8PmAm5fhwGz6JFTKe+HCBRtuwOEERSd1EN7TGKi
# xczSX8FJMz84dcOfALxjTj6RUF5TNSQLD2pACgYWl8MM0lEtD/1eif7TKMHqaA+s
# m/yJrlKEtOr836BvAgMBAAGjggHFMIIBwTAfBgNVHSMEGDAWgBRaxLl7Kgqjpepx
# A8Bg+S32ZXUOWDAdBgNVHQ4EFgQULh60SWOBOnU9TSFq0c2sWmMdu7EwDgYDVR0P
# AQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGA1UdHwRwMG4wNaAzoDGG
# L2h0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQtY3MtZzEuY3Js
# MDWgM6Axhi9odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVkLWNz
# LWcxLmNybDBMBgNVHSAERTBDMDcGCWCGSAGG/WwDATAqMCgGCCsGAQUFBwIBFhxo
# dHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAgGBmeBDAEEATCBhAYIKwYBBQUH
# AQEEeDB2MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wTgYI
# KwYBBQUHMAKGQmh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFNI
# QTJBc3N1cmVkSURDb2RlU2lnbmluZ0NBLmNydDAMBgNVHRMBAf8EAjAAMA0GCSqG
# SIb3DQEBCwUAA4IBAQBozpJhBdsaz19E9faa/wtrnssUreKxZVkYQ+NViWeyImc5
# qEZcDPy3Qgf731kVPnYuwi5S0U+qyg5p1CNn/WsvnJsdw8aO0lseadu8PECuHj1Z
# 5w4mi5rGNq+QVYSBB2vBh5Ps5rXuifBFF8YnUyBc2KuWBOCq6MTRN1H2sU5LtOUc
# Qkacv8hyom8DHERbd3mIBkV8fmtAmvwFYOCsXdBHOSwQUvfs53GySrnIYiWT0y56
# mVYPwDj7h/PdWO5hIuZm6n5ohInLig1weiVDJ254r+2pfyyRT+02JVVxyHFMCLwC
# ASs4vgbiZzMDltmoTDHz9gULxu/CfBGM0waMDu3cMIIFMDCCBBigAwIBAgIQBAkY
# G1/Vu2Z1U0O1b5VQCDANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMG
# A1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQw
# IgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTMxMDIyMTIw
# MDAwWhcNMjgxMDIyMTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhE
# aWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+NOzHH8OEa9ndwfTCzFJGc/Q+0WZsTrb
# RPV/5aid2zLXcep2nQUut4/6kkPApfmJ1DcZ17aq8JyGpdglrA55KDp+6dFn08b7
# KSfH03sjlOSRI5aQd4L5oYQjZhJUM1B0sSgmuyRpwsJS8hRniolF1C2ho+mILCCV
# rhxKhwjfDPXiTWAYvqrEsq5wMWYzcT6scKKrzn/pfMuSoeU7MRzP6vIK5Fe7SrXp
# dOYr/mzLfnQ5Ng2Q7+S1TqSp6moKq4TzrGdOtcT3jNEgJSPrCGQ+UpbB8g8S9MWO
# D8Gi6CxR93O8vYWxYoNzQYIH5DiLanMg0A9kczyen6Yzqf0Z3yWT0QIDAQABo4IB
# zTCCAckwEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0l
# BAwwCgYIKwYBBQUHAwMweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwgYEGA1Ud
# HwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwTwYDVR0gBEgwRjA4BgpghkgB
# hv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9D
# UFMwCgYIYIZIAYb9bAMwHQYDVR0OBBYEFFrEuXsqCqOl6nEDwGD5LfZldQ5YMB8G
# A1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMA0GCSqGSIb3DQEBCwUAA4IB
# AQA+7A1aJLPzItEVyCx8JSl2qB1dHC06GsTvMGHXfgtg/cM9D8Svi/3vKt8gVTew
# 4fbRknUPUbRupY5a4l4kgU4QpO4/cY5jDhNLrddfRHnzNhQGivecRk5c/5CxGwcO
# kRX7uq+1UcKNJK4kxscnKqEpKBo6cSgCPC6Ro8AlEeKcFEehemhor5unXCBc2XGx
# DI+7qPjFEmifz0DLQESlE/DmZAwlCEIysjaKJAL+L3J+HNdJRZboWR3p+nRka7Lr
# ZkPas7CM1ekN3fYBIM6ZMWM9CBoYs4GbT8aTEAb8B4H6i9r5gkn3Ym6hU/oSlBiF
# LpKR6mhsRDKyZqHnGKSaZFHvMYIELzCCBCsCAQEwgYYwcjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIENvZGUgU2lnbmlu
# ZyBDQQIQB6Zc7QsNL9EyTYMCYZHvVTAJBgUrDgMCGgUAoHAwEAYKKwYBBAGCNwIB
# DDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFODU8WtJloJN7ukthkKOSuSu
# SiubMA0GCSqGSIb3DQEBAQUABIIBAK+fLlmlsi0oy0EtuhI8k/DhlYVheNFLzW/E
# 8NfMxCbw4jxxdvY7JrxqRy4H+PaOAS3zJ3VaIu8V2azw1akO1h6Trz6xSCp2i6+J
# JkteFCYU96yP8ko9E3OTAKIEQF57Lm/0pLRKNB4VBNkzlnmpQGUBdAzow5UqPF9w
# 28sV0rDs8PdNSQIMFg4ILA5cWXu+Guh04gHSdEKKXEi9wm9jCzxDKbnGuoq6m4fe
# wdwyfYEMsnVHZOcCOnh5306UFd3QIElWcEi0poR7Jo0ZZQJh8z1WZXgytu76bh/5
# octSX9AvMhoyKsz9HMvESMwev70M7XoKd+CyqQBV2mJNqfsLOAmhggILMIICBwYJ
# KoZIhvcNAQkGMYIB+DCCAfQCAQEwcjBeMQswCQYDVQQGEwJVUzEdMBsGA1UEChMU
# U3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFudGVjIFRpbWUgU3Rh
# bXBpbmcgU2VydmljZXMgQ0EgLSBHMgIQDs/0OMj+vzVuBNhqmBsaUDAJBgUrDgMC
# GgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcN
# MTcxMjA4MTQ0NDM0WjAjBgkqhkiG9w0BCQQxFgQUwsXDoUVNDbLHQmGqrjIO5bfS
# S7kwDQYJKoZIhvcNAQEBBQAEggEAi1He3abW1yZZ9Ig9hDuWpimKwBnh9kK7AbS3
# Oe1lbvdmrzTO1Bzk+lUv5wafbza1k2VN2xVDbSjdEmvicpGhN3oamgwQPLcBX/uE
# 5yXm3XcABaTcAopQ9IRHFe2K6VtWerXI9YeM2QLfX4RJtVdJ9lk1aoU3wyhfqksS
# JURB7mYV92KFJrcg51ssSuKpiGwkhRJaws9AG1dtla9CnHu2DWpXuzyeRpWTbspp
# Oo2DUpThpo+j4GX9qDrv+v6taYsIUcSt9vFIOg+NC/ANHOiflxANeQVJItkvfCpE
# Wa2vpaIrRbxDVxiCTFfOIqBfOroRBdMJBNtp61uiXz9Z1jMzqw==
# SIG # End signature block
