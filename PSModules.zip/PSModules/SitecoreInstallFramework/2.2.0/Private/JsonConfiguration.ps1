<#
    Private scoped functions supporting parsing of json configuration
#>

Set-StrictMode -Version 2.0

$script:reevaluateVar = $false
function GetSection {
    param(
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$InputObject,
        [Parameter(Mandatory = $true)]
        [string]$Section
    )

    if ($InputObject.HasMember($Section)) {
        return $InputObject.$section
    }

    $null
}

function MapParameters {
    param(
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$InputObject,
        [hashtable]$Overrides = @{}
    )
    $processedParams = @{}
    $references = @{}
    if ($_ = GetSection -InputObject $InputObject -Section 'Parameters') {
        foreach ($member in $_.GetMembers()) {
            $param = [pscustomobject]@{
                Name  = $member.Name
                Value = $null
            }

            if ($member.Value.HasMember("Validate")) {
                $param | Add-Member -Name RawValidate -MemberType NoteProperty -Value $member.Value.Validate
                $param | Add-Member -MemberType ScriptMethod -Name Validate -Value {
                    param(
                        [Parameter(Mandatory = $true)]
                        [hashtable]$Parameters = @{},
                        [Parameter(Mandatory = $true)]
                        [hashtable]$Variables = @{}
                    )

                    $result = EvaluateObject -InputObject $this.RawValidate -Parameters $Parameters -Variables $Variables -ExternalArgs @{ _ = $this.Value }

                    if ($result -is [System.Collections.IEnumerable]) {
                        return $result -notcontains $false
                    }

                    return $result
                }
            }

            if (!$Overrides.Contains($member.Name)) {
                $hasDefault = $member.Value.HasMember('DefaultValue')
                $hasReference = $member.Value.HasMember('Reference')

                if ($hasDefault -and $hasReference) {
                    throw "Parameter '$($member.Name)' contains a default value and a reference.  Only one can be used at a time."
                }

                if (!$hasDefault -and !$hasReference) {
                    continue;
                }

                if ($hasDefault) {
                    $param.Value = $member.Value.DefaultValue
                } elseif ($hasReference) {
                    $references[$member.Name] = $member.Value.Reference
                }
            }

            $processedParams[$member.Name] = $param
        }
    }

    foreach ($key in $Overrides.Keys) {
        if ($processedParams.Contains($key)) {
            $processedParams[$key].Value = $Overrides[$key]
        } else {
            $processedParams[$key] = [pscustomobject]@{
                Name  = $key
                Value = $Overrides[$key]
            }
        }
    }

    $processedParams = DereferencePointers -References $references -Processed $processedParams

    $processedParams
}

function DereferencePointers {
    param(
        [Parameter(Mandatory = $true)]
        [hashtable]$References,
        [Parameter(Mandatory = $true)]
        [hashtable]$Processed
    )

    function ProcessKey {
        param(
            [string]$Key,
            [string[]]$Chain = @($Key)
        )

        $pointer = $references[$Key]
        if ($Processed.Keys -contains $pointer -and $References.Keys -notcontains $pointer) {
            # Update every entry in chain
            $Chain.ForEach( {
                    $processed[$_].Value = $Processed[$pointer].Value
                    $References.Remove($_)
                })
        } elseif ($References.Keys -contains $pointer) {
            if ($Chain -contains $pointer) {
                $Chain += $pointer
                $errorChain = $Chain -join ' => '
                throw "Parameter '$($Chain[0])' contains circular reference: $errorChain"
            }
            $Chain += $pointer
            ProcessKey $Pointer -Chain $Chain
        } else {
            throw "Parameter '$Key' references unknown parameter: $pointer."
        }
    }

    while ($References.Keys.Count -gt 0) {
        ProcessKey @($References.Keys)[0]
    }

    $processed
}

function MapVariables {
    param(
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$InputObject,
        [hashtable]$Parameters = @{}
    )

    $processedVariables = @{}
    if ($_ = GetSection -InputObject $InputObject -Section 'Variables') {
        foreach ($member in $_.GetMembers()) {
            $resolvedVar = [pscustomobject]@{
                Name           = $member.Name
                RawValue       = $member.Value
                ProcessedValue = $null
                Evaluated      = $false
            }
            $resolvedVar | Add-Member -MemberType ScriptMethod -Name Evaluate -Value {
                param(
                    [Parameter(Mandatory = $true)]
                    [hashtable]$Parameters = @{},
                    [Parameter(Mandatory = $true)]
                    [hashtable]$Variables = @{}
                )

                if ($script:reevaluateVar -or !$this.Evaluated) {
                    $this.ProcessedValue = EvaluateObject -InputObject $this.RawValue -Parameters $Parameters -Variables $Variables
                    $this.Evaluated = $true
                }
                return , $this.ProcessedValue
            }

            $processedVariables[$member.Name] = $resolvedVar
        }
    }

    $processedVariables
}

function MapTasks {
    param(
        [Parameter(Mandatory)]
        [PSCustomObject]$InputObject,
        [Parameter(Mandatory)]
        [ValidateSet ('Tasks','UninstallTasks')]
        [string]$TasksToExecute
    )

    try {
        $processedTasks = [ordered]@{}
        if($_ = GetSection -Section $TasksToExecute -InputObject $InputObject) {
            # Validate Task structure
            foreach ($entry in $_.GetMembers()) {
                $task = $entry.Value
                if (-not $task.HasMember('Type')) {
                    throw "Task '$($entry.Name)' is missing a 'Type' property"
                }
                # Set the command to invoke
                $task | Add-Member -Name Command -MemberType NoteProperty -Value (ResolveExtension -Id $task.Type -Type Task)
                if (!$task.HasMember('Skip')) {
                    $task | Add-Member -Name Skip -MemberType NoteProperty -Value $false
                }
                $processedTasks[$entry.Name] = $task
            }
        }

        $processedTasks
    } catch {
        Write-Error $_
    }
}

function EvaluateObject {
    param(
        [Parameter(Mandatory = $true)]
        [AllowNull()]
        [AllowEmptyString()]
        [AllowEmptyCollection()]
        $InputObject,
        [hashtable]$Parameters = @{},
        [hashtable]$Variables = @{},
        [hashtable]$ExternalArgs = @{}
    )
    # Null check
    if ($null -eq $InputObject) { return $null }

    # String check
    if ($InputObject -is [string]) {
        if (ValidateConfigFunctionFormat -FunctionText $InputObject) {
            return GetConfigFunctionResult -FunctionText $InputObject -Parameters $Parameters -Variables $Variables -ExternalArgs $ExternalArgs
        }
        return $InputObject
    }

    # Hashtable check
    if ($InputObject -is [hashtable]) {
        $InputObject = [pscustomobject]$InputObject
    }

    # Object check
    if ($InputObject -is [psobject]) {
        $result = [ordered]@{}
        $members = $InputObject.GetMembers()
        foreach ($member in $members) {
            $result[$member.Name] = EvaluateObject $member.Value -Parameters $Parameters -Variables $Variables -ExternalArgs $ExternalArgs
        }

        return $result
    }

    # Enumerable check
    if ($InputObject -is [System.Collections.IEnumerable]) {
        $collection = New-Object System.Collections.Arraylist
        foreach ($object in $InputObject) {
            $evaluated = EvaluateObject $object -Parameters $Parameters -Variables $Variables  -ExternalArgs $ExternalArgs
            [void]$collection.Add($evaluated)
        }

        # If the array is empty, we _must_ say no enumerate to ensure it
        # is not then translated as $null when returned
        $result = $collection.ToArray()
        if (!$result) {
            Write-Output $result -NoEnumerate
            return
        }
        return $result
    }

    # Default
    return $InputObject
}
# SIG # Begin signature block
# MIIXwQYJKoZIhvcNAQcCoIIXsjCCF64CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUI8qItKnc/w6qkHJZGKrhKEtG
# tVGgghL8MIID7jCCA1egAwIBAgIQfpPr+3zGTlnqS5p31Ab8OzANBgkqhkiG9w0B
# AQUFADCBizELMAkGA1UEBhMCWkExFTATBgNVBAgTDFdlc3Rlcm4gQ2FwZTEUMBIG
# A1UEBxMLRHVyYmFudmlsbGUxDzANBgNVBAoTBlRoYXd0ZTEdMBsGA1UECxMUVGhh
# d3RlIENlcnRpZmljYXRpb24xHzAdBgNVBAMTFlRoYXd0ZSBUaW1lc3RhbXBpbmcg
# Q0EwHhcNMTIxMjIxMDAwMDAwWhcNMjAxMjMwMjM1OTU5WjBeMQswCQYDVQQGEwJV
# UzEdMBsGA1UEChMUU3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFu
# dGVjIFRpbWUgU3RhbXBpbmcgU2VydmljZXMgQ0EgLSBHMjCCASIwDQYJKoZIhvcN
# AQEBBQADggEPADCCAQoCggEBALGss0lUS5ccEgrYJXmRIlcqb9y4JsRDc2vCvy5Q
# WvsUwnaOQwElQ7Sh4kX06Ld7w3TMIte0lAAC903tv7S3RCRrzV9FO9FEzkMScxeC
# i2m0K8uZHqxyGyZNcR+xMd37UWECU6aq9UksBXhFpS+JzueZ5/6M4lc/PcaS3Er4
# ezPkeQr78HWIQZz/xQNRmarXbJ+TaYdlKYOFwmAUxMjJOxTawIHwHw103pIiq8r3
# +3R8J+b3Sht/p8OeLa6K6qbmqicWfWH3mHERvOJQoUvlXfrlDqcsn6plINPYlujI
# fKVOSET/GeJEB5IL12iEgF1qeGRFzWBGflTBE3zFefHJwXECAwEAAaOB+jCB9zAd
# BgNVHQ4EFgQUX5r1blzMzHSa1N197z/b7EyALt0wMgYIKwYBBQUHAQEEJjAkMCIG
# CCsGAQUFBzABhhZodHRwOi8vb2NzcC50aGF3dGUuY29tMBIGA1UdEwEB/wQIMAYB
# Af8CAQAwPwYDVR0fBDgwNjA0oDKgMIYuaHR0cDovL2NybC50aGF3dGUuY29tL1Ro
# YXd0ZVRpbWVzdGFtcGluZ0NBLmNybDATBgNVHSUEDDAKBggrBgEFBQcDCDAOBgNV
# HQ8BAf8EBAMCAQYwKAYDVR0RBCEwH6QdMBsxGTAXBgNVBAMTEFRpbWVTdGFtcC0y
# MDQ4LTEwDQYJKoZIhvcNAQEFBQADgYEAAwmbj3nvf1kwqu9otfrjCR27T4IGXTdf
# plKfFo3qHJIJRG71betYfDDo+WmNI3MLEm9Hqa45EfgqsZuwGsOO61mWAK3ODE2y
# 0DGmCFwqevzieh1XTKhlGOl5QGIllm7HxzdqgyEIjkHq3dlXPx13SYcqFgZepjhq
# IhKjURmDfrYwggSjMIIDi6ADAgECAhAOz/Q4yP6/NW4E2GqYGxpQMA0GCSqGSIb3
# DQEBBQUAMF4xCzAJBgNVBAYTAlVTMR0wGwYDVQQKExRTeW1hbnRlYyBDb3Jwb3Jh
# dGlvbjEwMC4GA1UEAxMnU3ltYW50ZWMgVGltZSBTdGFtcGluZyBTZXJ2aWNlcyBD
# QSAtIEcyMB4XDTEyMTAxODAwMDAwMFoXDTIwMTIyOTIzNTk1OVowYjELMAkGA1UE
# BhMCVVMxHTAbBgNVBAoTFFN5bWFudGVjIENvcnBvcmF0aW9uMTQwMgYDVQQDEytT
# eW1hbnRlYyBUaW1lIFN0YW1waW5nIFNlcnZpY2VzIFNpZ25lciAtIEc0MIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAomMLOUS4uyOnREm7Dv+h8GEKU5Ow
# mNutLA9KxW7/hjxTVQ8VzgQ/K/2plpbZvmF5C1vJTIZ25eBDSyKV7sIrQ8Gf2Gi0
# jkBP7oU4uRHFI/JkWPAVMm9OV6GuiKQC1yoezUvh3WPVF4kyW7BemVqonShQDhfu
# ltthO0VRHc8SVguSR/yrrvZmPUescHLnkudfzRC5xINklBm9JYDh6NIipdC6Anqh
# d5NbZcPuF3S8QYYq3AhMjJKMkS2ed0QfaNaodHfbDlsyi1aLM73ZY8hJnTrFxeoz
# C9Lxoxv0i77Zs1eLO94Ep3oisiSuLsdwxb5OgyYI+wu9qU+ZCOEQKHKqzQIDAQAB
# o4IBVzCCAVMwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAO
# BgNVHQ8BAf8EBAMCB4AwcwYIKwYBBQUHAQEEZzBlMCoGCCsGAQUFBzABhh5odHRw
# Oi8vdHMtb2NzcC53cy5zeW1hbnRlYy5jb20wNwYIKwYBBQUHMAKGK2h0dHA6Ly90
# cy1haWEud3Muc3ltYW50ZWMuY29tL3Rzcy1jYS1nMi5jZXIwPAYDVR0fBDUwMzAx
# oC+gLYYraHR0cDovL3RzLWNybC53cy5zeW1hbnRlYy5jb20vdHNzLWNhLWcyLmNy
# bDAoBgNVHREEITAfpB0wGzEZMBcGA1UEAxMQVGltZVN0YW1wLTIwNDgtMjAdBgNV
# HQ4EFgQURsZpow5KFB7VTNpSYxc/Xja8DeYwHwYDVR0jBBgwFoAUX5r1blzMzHSa
# 1N197z/b7EyALt0wDQYJKoZIhvcNAQEFBQADggEBAHg7tJEqAEzwj2IwN3ijhCcH
# bxiy3iXcoNSUA6qGTiWfmkADHN3O43nLIWgG2rYytG2/9CwmYzPkSWRtDebDZw73
# BaQ1bHyJFsbpst+y6d0gxnEPzZV03LZc3r03H0N45ni1zSgEIKOq8UvEiCmRDoDR
# EfzdXHZuT14ORUZBbg2w6jiasTraCXEQ/Bx5tIB7rGn0/Zy2DBYr8X9bCT2bW+IW
# yhOBbQAuOA2oKY8s4bL0WqkBrxWcLC9JG9siu8P+eJRRw4axgohd8D20UaF5Mysu
# e7ncIAkTcetqGVvP6KUwVyyJST+5z3/Jvz4iaGNTmr1pdKzFHTx/kuDDvBzYBHUw
# ggUrMIIEE6ADAgECAhAHplztCw0v0TJNgwJhke9VMA0GCSqGSIb3DQEBCwUAMHIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJ
# RCBDb2RlIFNpZ25pbmcgQ0EwHhcNMTcwODIzMDAwMDAwWhcNMjAwOTMwMTIwMDAw
# WjBoMQswCQYDVQQGEwJVUzELMAkGA1UECBMCY2ExEjAQBgNVBAcTCVNhdXNhbGl0
# bzEbMBkGA1UEChMSU2l0ZWNvcmUgVVNBLCBJbmMuMRswGQYDVQQDExJTaXRlY29y
# ZSBVU0EsIEluYy4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC7PZ/g
# huhrQ/p/0Cg7BRrYjw7ZMx8HNBamEm0El+sedPWYeAAFrjDSpECxYjvK8/NOS9dk
# tC35XL2TREMOJk746mZqia+g+NQDPEaDjNPG/iT0gWsOeCa9dUcIUtnBQ0hBKsuR
# bau3n7w1uIgr3zf29vc9NhCoz1m2uBNIuLBlkKguXwgPt4rzj66+18JV3xyLQJoS
# 3ZAA8k6FnZltNB+4HB0LKpPmF8PmAm5fhwGz6JFTKe+HCBRtuwOEERSd1EN7TGKi
# xczSX8FJMz84dcOfALxjTj6RUF5TNSQLD2pACgYWl8MM0lEtD/1eif7TKMHqaA+s
# m/yJrlKEtOr836BvAgMBAAGjggHFMIIBwTAfBgNVHSMEGDAWgBRaxLl7Kgqjpepx
# A8Bg+S32ZXUOWDAdBgNVHQ4EFgQULh60SWOBOnU9TSFq0c2sWmMdu7EwDgYDVR0P
# AQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGA1UdHwRwMG4wNaAzoDGG
# L2h0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQtY3MtZzEuY3Js
# MDWgM6Axhi9odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVkLWNz
# LWcxLmNybDBMBgNVHSAERTBDMDcGCWCGSAGG/WwDATAqMCgGCCsGAQUFBwIBFhxo
# dHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAgGBmeBDAEEATCBhAYIKwYBBQUH
# AQEEeDB2MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wTgYI
# KwYBBQUHMAKGQmh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFNI
# QTJBc3N1cmVkSURDb2RlU2lnbmluZ0NBLmNydDAMBgNVHRMBAf8EAjAAMA0GCSqG
# SIb3DQEBCwUAA4IBAQBozpJhBdsaz19E9faa/wtrnssUreKxZVkYQ+NViWeyImc5
# qEZcDPy3Qgf731kVPnYuwi5S0U+qyg5p1CNn/WsvnJsdw8aO0lseadu8PECuHj1Z
# 5w4mi5rGNq+QVYSBB2vBh5Ps5rXuifBFF8YnUyBc2KuWBOCq6MTRN1H2sU5LtOUc
# Qkacv8hyom8DHERbd3mIBkV8fmtAmvwFYOCsXdBHOSwQUvfs53GySrnIYiWT0y56
# mVYPwDj7h/PdWO5hIuZm6n5ohInLig1weiVDJ254r+2pfyyRT+02JVVxyHFMCLwC
# ASs4vgbiZzMDltmoTDHz9gULxu/CfBGM0waMDu3cMIIFMDCCBBigAwIBAgIQBAkY
# G1/Vu2Z1U0O1b5VQCDANBgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMG
# A1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQw
# IgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTMxMDIyMTIw
# MDAwWhcNMjgxMDIyMTIwMDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhE
# aWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA+NOzHH8OEa9ndwfTCzFJGc/Q+0WZsTrb
# RPV/5aid2zLXcep2nQUut4/6kkPApfmJ1DcZ17aq8JyGpdglrA55KDp+6dFn08b7
# KSfH03sjlOSRI5aQd4L5oYQjZhJUM1B0sSgmuyRpwsJS8hRniolF1C2ho+mILCCV
# rhxKhwjfDPXiTWAYvqrEsq5wMWYzcT6scKKrzn/pfMuSoeU7MRzP6vIK5Fe7SrXp
# dOYr/mzLfnQ5Ng2Q7+S1TqSp6moKq4TzrGdOtcT3jNEgJSPrCGQ+UpbB8g8S9MWO
# D8Gi6CxR93O8vYWxYoNzQYIH5DiLanMg0A9kczyen6Yzqf0Z3yWT0QIDAQABo4IB
# zTCCAckwEgYDVR0TAQH/BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0l
# BAwwCgYIKwYBBQUHAwMweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwgYEGA1Ud
# HwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwTwYDVR0gBEgwRjA4BgpghkgB
# hv1sAAIEMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9D
# UFMwCgYIYIZIAYb9bAMwHQYDVR0OBBYEFFrEuXsqCqOl6nEDwGD5LfZldQ5YMB8G
# A1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3zbcgPMA0GCSqGSIb3DQEBCwUAA4IB
# AQA+7A1aJLPzItEVyCx8JSl2qB1dHC06GsTvMGHXfgtg/cM9D8Svi/3vKt8gVTew
# 4fbRknUPUbRupY5a4l4kgU4QpO4/cY5jDhNLrddfRHnzNhQGivecRk5c/5CxGwcO
# kRX7uq+1UcKNJK4kxscnKqEpKBo6cSgCPC6Ro8AlEeKcFEehemhor5unXCBc2XGx
# DI+7qPjFEmifz0DLQESlE/DmZAwlCEIysjaKJAL+L3J+HNdJRZboWR3p+nRka7Lr
# ZkPas7CM1ekN3fYBIM6ZMWM9CBoYs4GbT8aTEAb8B4H6i9r5gkn3Ym6hU/oSlBiF
# LpKR6mhsRDKyZqHnGKSaZFHvMYIELzCCBCsCAQEwgYYwcjELMAkGA1UEBhMCVVMx
# FTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
# bTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElEIENvZGUgU2lnbmlu
# ZyBDQQIQB6Zc7QsNL9EyTYMCYZHvVTAJBgUrDgMCGgUAoHAwEAYKKwYBBAGCNwIB
# DDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFPbo5ox3033ZGu2mN7YFz5hF
# nmvxMA0GCSqGSIb3DQEBAQUABIIBAGpkXBM7dp3f7fpRdPEKGmDbVW9IV7nJEGZE
# l3wHnPg6W9xooQyQUKYwmPAGg3Ziw9MdEZjVwpY3aP6UxEn3fv8/okpMZ4C2b9Uf
# +reojlP6DWb430ain5GM+QeXUHt7+wtXvUmH4eHCvdeSvhJCuf0Hosj9zeTEUgS5
# 3Moi6WrAd+1eTyQlVubk6BCFuNJjGFSQnXkVP5iEqqdNwwNf0xW5ufS/AeMkhl22
# cZLFM0lZcvyLL2C9eU5po8hGuneW4TM+Eaq+XgPDRjYFYlFHptSX1/7/sqL8P6+r
# sy9GHggg4r9R9KDKmOFbaNNS9236uiRZba6kgdTQEhxtdrIOhb6hggILMIICBwYJ
# KoZIhvcNAQkGMYIB+DCCAfQCAQEwcjBeMQswCQYDVQQGEwJVUzEdMBsGA1UEChMU
# U3ltYW50ZWMgQ29ycG9yYXRpb24xMDAuBgNVBAMTJ1N5bWFudGVjIFRpbWUgU3Rh
# bXBpbmcgU2VydmljZXMgQ0EgLSBHMgIQDs/0OMj+vzVuBNhqmBsaUDAJBgUrDgMC
# GgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcN
# MTkwOTE2MjAyNjUzWjAjBgkqhkiG9w0BCQQxFgQUQN5K/vuMrMQoUcbwwRsDtXFF
# n2swDQYJKoZIhvcNAQEBBQAEggEASx/xlRejcR8PR4R85fA51my1IQtBnRI+FMU6
# CjT7/Lf42dijEsZcBUDrcxZGbRhaPzMQYUwyZFhvUsjaGCn3ZalcFgzp6qDTl3Wd
# Jya2CNnbPpc+ifYd4EiOR20NO+R4r5l0O47Krdd60prfMgrJC/ljxHxfIoYiedFO
# u5GvxesAN/EWMQx/H7yETVVKKxRYQsCQZ5BL/e+vtXRkafPRY96h7vTQq8XvPTvl
# +JjNclduXoQHzgtEmp2LIGBGwnv61EpQQaJqJKAiE9zkERGJ//1BdJybf/5M5os+
# Q3pHL2JEpZCUCKhoiMjl72eEXPgqB2zTAeWCd8GKbtf+kN4PHw==
# SIG # End signature block
