---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-NewRootCertificateTask

## SYNOPSIS
Creates a new Root Certificate Authority

## SYNTAX

```
Invoke-NewRootCertificateTask [[-DnsName] <String[]>] [[-StoreLocation] <StoreLocation>]
 [[-FriendlyName] <String>] [[-Path] <String>] [[-Name] <String>] [-IncludePrivateKey]
 [[-Password] <SecureString>] [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
Creates a new Root Certificate Authority suitable for signing subordinate certificates.

It is strongly recommended that all certificates are created in the LocalMachine context.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-NewRootCertificateTask
```

Creates a Root Certificate Authority in the default location of Cert:\LocalMachine\root

## PARAMETERS

### -DnsName
A list of DNS names to be included in the certificate. The first item will be the
issuer Common Name (CN). All items will be included as Subject Alternative Names.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -FriendlyName
The friendly name for the certificate.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -IncludePrivateKey
If required the private key will be included in the file. Certificates with private
keys are exported as a PFX file.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Name
The filename for the exported certificate.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Password
A Secure String object to use as a password for the exported certificate. 

```yaml
Type: SecureString
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Path
If supplied the certificate will be exported to this location.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -StoreLocation
The store the certificate is created in. This must be either LocalMachine or
CurrentUser. The certificate will be created in the root folder of the specified
StoreLocation

```yaml
Type: StoreLocation
Parameter Sets: (All)
Aliases:
Accepted values: LocalMachine, CurrentUser

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
