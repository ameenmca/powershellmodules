---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-ValidateNotNullOrEmptyConfigFunction

## SYNOPSIS
Validates that the argument is not null and is not an empty string or collection

## SYNTAX

```
Invoke-ValidateNotNullOrEmptyConfigFunction [-param] <Object> [<CommonParameters>]
```

## DESCRIPTION
Returns `$true` if parameter is not `$null` and not empty string or collection, otherwise `$false`.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-ValidateNotNullOrEmptyConfigFunction -param "Value"
PS C:\> $true
```

The parameter is not empty string, result is `$true`.

### Example 2
```powershell
PS C:\> Invoke-ValidateNotNullOrEmptyConfigFunction -param ""
PS C:\> $false
```

The parameter is empty string, result is `$false`.

### Example 2
```powershell
PS C:\> Invoke-ValidateNotNullOrEmptyConfigFunction -param @(1,2,3)
PS C:\> $false
```

The parameter is not empty array, result is `$true`.

## PARAMETERS

### -param
The parameter to validate.

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
