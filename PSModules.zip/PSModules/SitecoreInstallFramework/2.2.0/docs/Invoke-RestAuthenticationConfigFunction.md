---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-RestAuthenticationConfigFunction

## SYNOPSIS
Performs authentication to the REST endpoint specified with `LoginUri` parameter by posting username as `Username` parameter and password as `Password`.

## SYNTAX

```
Invoke-RestAuthenticationConfigFunction [-LoginUri] <String> [-Username] <String> [-Password] <String>
 [<CommonParameters>]
```

## DESCRIPTION
Returns the session of performing login to the specified URI with specified username and password.
If specified username and password don't sutisfy the result returned by function is `null`

This config function can be used together with `Invoke-DownloadTask` to download files from the store wich requires authentication.

## EXAMPLES

### Example 1
```
PS C:\> Invoke-RestAuthenticationConfigFunction -LoginUri 'https://dev.sitecore.net/api/authorization' -Username 'dev@sitecore.com' -Password 'SomePassword'
```

Returns web session if the credentials satisfy authentication service and `null` in opposite case.

## PARAMETERS

### -LoginUri
Authentication URI endpoint.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Password
Password to be logged in with

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Username
Username for login.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### String

## OUTPUTS

### Microsoft.PowerShell.Commands.WebRequestSession

## NOTES

## RELATED LINKS
