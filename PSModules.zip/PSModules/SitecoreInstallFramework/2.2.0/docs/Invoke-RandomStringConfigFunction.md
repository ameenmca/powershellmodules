---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-RandomStringConfigFunction

## SYNOPSIS
Generates a random string of the specified length.

## SYNTAX

```
Invoke-RandomStringConfigFunction [-Length] <Int32> [-EnforceComplexity] [-DisallowSpecial] [-DisallowCaps]
 [-DisallowLower] [-DisallowNumbers] [<CommonParameters>]
```

## DESCRIPTION
Generates a random string of the specified length using one or more of the allowed types.
It will optionally generate the string containing capital letters, lowercase, numbers
and the ASCII special printable characters.
The `-EnforceComplexity` option will ensure that at least one of each of the allowed
types are present in the string.

## EXAMPLES

### Example 1
```
PS C:\> Invoke-RandomStringConfigFunction -Length 10
wO_R!WC(`?
```

Returns a string of length 10 using all available characters.

### Example 2
```
PS C:\> Invoke-RandomStringConfigFunction -Length 10 -DisallowCaps -DisallowNumbers -DisallowSpecial
UXLIINHIOW
```

Returns a string of length 10 using only capital letters.

### Example 3
```
PS C:\> Invoke-RandomStringConfigFunction -Length 10 -EnforceComplexity -DisallowSpecial
8stGlLRjpp
```

Returns a string of length 10 without any of the special printable characters and
requiring at least one each of the allowed characters (caps, lower and numbers)

### Example 4
```
PS C:\> Invoke-RandomStringConfigFunction -Length 8 -DisallowSpecial -DisallowCaps -DisallowLower
07923743
```

Returns a string of length 8 using only numbers. Note this is still returned as a string not an int.

## PARAMETERS

### -DisallowCaps
Prevent capital letters from appearing in the generated sting.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DisallowLower
Prevent lower case letters from appearing in the generated string.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DisallowNumbers
Prevent numbers from appearing in the generated string.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: 5
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DisallowSpecial
Prevent the special characters ~!@#$%^&*_-+=`|\(){}[]:;<>.?/

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -EnforceComplexity
Ensures the returned string contains at least one of each of the allowed character
types.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Length
The length of the returned string.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
