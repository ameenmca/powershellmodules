---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-ValidateRangeConfigFunction

## SYNOPSIS
Validates that number parameter falls in the range specified by Min and Max.

## SYNTAX

```
Invoke-ValidateRangeConfigFunction [[-Min] <Double>] [[-Max] <Double>] [-Param] <Double> [<CommonParameters>]
```

## DESCRIPTION
Returns `$true` if parameters value falls in the range of Min to Max, otherwise `$false`.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-ValidateRangeConfigFunction -Min 100 -Max 500 -Param 400
PS C:\> $true
```

The parameter value is 400, which falls in the range of 100 to 500, result is `$true`.

### Example 2
```powershell
PS C:\> Invoke-ValidateRangeConfigFunction -Min 100 -Max 500 -Param 600
PS C:\> $false
```

The parameter value is 600, which doesn't fall in the range of 100 to 500, result is `$false`.

## PARAMETERS

### -Max
The maximum value for parameter.

```yaml
Type: Double
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Min
The minimum value for parameter.

```yaml
Type: Double
Parameter Sets: (All)
Aliases:

Required: False
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Param
The parameter to validate.

```yaml
Type: Double
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
