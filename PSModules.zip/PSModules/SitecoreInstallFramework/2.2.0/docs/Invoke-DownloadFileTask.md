---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-DownloadFileTask

## SYNOPSIS
Task to support the downloading of files from the Internet.

## SYNTAX

```
Invoke-DownloadFileTask [-SourceUri] <String> [-DestinationPath] <String> [[-LoginSession] <WebRequestSession>]
 [[-Credentials] <PSCredential>] [[-Hash] <String>] [[-Algorithm] <String>] [-WhatIf] [-Confirm]
 [<CommonParameters>]
```

## DESCRIPTION
The Invoke-DownloadFileTask cmdlet sends HTTP, HTTPS, FTP, and FILE requests to a given URL and saves the downloaded file to a specified destination. Supports downloading with credentials and web authentication.

## EXAMPLES

### Example 1
```
PS C:\> Invoke-DownloadFileTask -SourceUrl http://www.somedomain.com/SomeFile.txt -DestinationPath C:\Temp\SomeFile.txt
```

### Example 2
```
PS (Invoke-RestMethod -Uri 'https://dev.sitecore.net/api/authorization' -Method Post -ContentType "application/json"  -Body "{username:'yourUserName', password:'yourPassword'}" -SessionVariable session)
PS C:\> Invoke-DownloadFileTask -SourceUrl http://www.somedomain.com/SomeFile.txt -DestinationPath C:\Temp\SomeFile.txt -LoginSession $session
```

### Example 3
```
PS $userPr = "userName"
PS $secpasswd = ConvertTo-SecureString "userPwd" -AsPlainText -Force
PS $credential = New-Object System.Management.Automation.PSCredential($userPr, $secpasswd)
PS C:\> Invoke-DownloadFileTask -SourceUrl http://www.somedomain.com/SomeFile.txt -DestinationPath C:\Temp\SomeFile.txt -Credentials $credential
```

This downloads the file 'SomeFile.txt' from 'www.somedomain.com' and saves it to 'C:\Temp\SomeFile.txt'

### Example 4
```
PS C:\> Invoke-DownloadFileTask -SourceUrl http://www.somedomain.com/SomeFile.txt -DestinationPath C:\Temp\SomeFile.txt -Hash "0F1ABA50CC16441AAB48149BA3E4CB8A442EEAAB00DF74FD32AD109606AFAB05"
```

This downloads the file 'SomeFile.txt' from 'www.somedomain.com' and saves it to 'C:\Temp\SomeFile.txt' and compares it to the supplied SHA256 Hash 0F1ABA50CC16441AAB48149BA3E4CB8A442EEAAB00DF74FD32AD109606AFAB05.

### Example 5
```
PS C:\> Invoke-DownloadFileTask -SourceUrl http://www.somedomain.com/SomeFile.txt -DestinationPath C:\Temp\SomeFile.txt -Hash "36AEA485C9F887B06ECAEF1331F16B05A806FA41" -Algorithm SHA1
```

This downloads the file 'SomeFile.txt' from 'www.somedomain.com' and saves it to 'C:\Temp\SomeFile.txt' and compares it to the supplied SHA1 Hash 36AEA485C9F887B06ECAEF1331F16B05A806FA41.

## PARAMETERS

### -Algorithm
Uses the specified hashing algorithm. SHA256 by default.

```yaml
Type: String
Parameter Sets: (All)
Aliases:
Accepted values: MACTripleDES, MD5, RIPEMD160, SHA1, SHA256, SHA384, SHA512

Required: False
Position: 5
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Credentials
Specifies the credentials to be used for authorization.

```yaml
Type: PSCredential
Parameter Sets: (All)
Aliases:

Required: False
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DestinationPath
Specifies the location for which this cmdlet saves the downloaded file. Enter a path and file name. If you omit the path, the default is the current location.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Hash
If supplied the downloaded file will be checked against this hash. SHA256 hash default.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: False
Position: 4
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -LoginSession
Specifies the session to be authorized with. Can be created by `Invoke-RestMethod`.

```yaml
Type: WebRequestSession
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SourceUri
Specifies the URL to obtain the file for download.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
