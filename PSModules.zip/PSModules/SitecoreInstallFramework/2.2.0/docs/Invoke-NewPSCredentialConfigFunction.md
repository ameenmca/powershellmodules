---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-NewPSCredentialConfigFunction

## SYNOPSIS
Creates and returns a Powershell credential object.

## SYNTAX

```
Invoke-NewPSCredentialConfigFunction [-Username] <String> [-Password] <SecureString> [<CommonParameters>]
```

## DESCRIPTION
Creates and returns a Powershell credential object for use with commands that require them.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-NewPSCredentialConfigFunction -Username User1 -Password (ConvertTo-SecureSting
-String 'Password123' -AsPlainText -Force)
```

Creates a Powershell credential object using the Username `User1` and the Password `Password123`.

## PARAMETERS

### -Password
A SecureString object of the password.

```yaml
Type: SecureString
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Username
The username to be used.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
