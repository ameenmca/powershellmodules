---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-RemoveSqlDatabaseTask

## SYNOPSIS
Removes given databases from the SQL Server.

## SYNTAX

```
Invoke-RemoveSqlDatabaseTask [-ServerName] <String> [-DatabaseNames] <String[]> [-UserName] <String>
 [-Password] <SecureString> [-WhatIf] [-Confirm] [<CommonParameters>]
```

## DESCRIPTION
Checks the SQL Server for databases to remove. If the database exists, all connections to it will be dropped and it will be removed.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-RemoveSqlDatabaseTask -ServerName "testServer1" -DatabaseNames "testDb1" -UserName "testUser1" -Password $password
```

This will establish connection to 'testServer1' SQL Server using 'testUser1' user and remove 'testDb1' database if it exists.

### Example 2
```powershell
PS C:\> Invoke-RemoveSqlDatabaseTask -ServerName "testServer1" -DatabaseNames "testDb1","testDb2" -UserName "testUser1" -Password $password
```

This will establish connection to 'testServer1' SQL Server using 'testUser1' user and remove 'testDb1' and 'testDb2' databases if they exist.

## PARAMETERS

### -DatabaseNames
Specifies a list of databases to remove.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: True
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Password
Specifies the password for the connection to the SQL Server.

```yaml
Type: SecureString
Parameter Sets: (All)
Aliases:

Required: True
Position: 3
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ServerName
Specifies the SQL Server to remove the databases from.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -UserName
Specifies the username for the connection to the SQL Server.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Confirm
Prompts you for confirmation before running the cmdlet.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: cf

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -WhatIf
Shows what would happen if the cmdlet runs.
The cmdlet is not run.

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases: wi

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
