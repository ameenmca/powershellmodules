---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-ValidateLengthConfigFunction

## SYNOPSIS
Validates that the parameter length falls in the range.

## SYNTAX

```
Invoke-ValidateLengthConfigFunction [[-MinLength] <Int32>] [[-MaxLength] <Int32>] [-Param] <String>
 [<CommonParameters>]
```

## DESCRIPTION
Returns `$true` if parameter length is in the range of `MinLength` to `MaxLength`, otherwise `$false`.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-ValidateLengthConfigFunction -MinLength 4 -MaxLength 6 -Param "April"
PS C:\> $true
```

The parameter has length of 5, which is in the range of 4 to 6, so result is `$true`.

### Example 2
```powershell
PS C:\> Invoke-ValidateLengthConfigFunction -MinLength 4 -MaxLength 6 -Param "May"
PS C:\> $false
```

The paramter has length of 3, which isn't in the range of 4 to 6, so result is `$false`.

## PARAMETERS

### -MaxLength
The maximum length of parameter.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -MinLength
The minimum length of parameter.

```yaml
Type: Int32
Parameter Sets: (All)
Aliases:

Required: False
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Param
The parameter to validate.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
