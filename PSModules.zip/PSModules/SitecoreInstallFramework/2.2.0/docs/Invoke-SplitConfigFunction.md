---
external help file: SitecoreInstallFramework-help.xml
Module Name: SitecoreInstallFramework
online version:
schema: 2.0.0
---

# Invoke-SplitConfigFunction

## SYNOPSIS
Splits a string.

## SYNTAX

```
Invoke-SplitConfigFunction [-String] <String> [[-Characters] <String[]>] [[-ElementsToReturn] <Int32[]>]
 [<CommonParameters>]
```

## DESCRIPTION
Splits a string by the given characters, returning the elements specified.

## EXAMPLES

### Example 1
```powershell
PS C:\> Invoke-SplitConfigFunction -String "abc def"
```

Splits the string 'abc def' by the space character and returns the first element 'abc'.

## PARAMETERS

### -Characters
Uses the supplied characters to split the string. e.g. @("."," ") will split the string using the . and space characters.

```yaml
Type: String[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ElementsToReturn
A zero indexed integer array of elements to return. e.g @(1,2) will return the second and third elements.

```yaml
Type: Int32[]
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -String
The string to split.

```yaml
Type: String
Parameter Sets: (All)
Aliases:

Required: True
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see about_CommonParameters (http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### None

## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS
